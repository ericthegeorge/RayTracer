/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package backend_models;

import java.util.Arrays;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author erick
 * @param <VecType>
 */
public interface Vec3Math<VecType extends Vec3Math> {

    VecType self(); // must return this;

    double[] e(); // return this.e;

    VecType setE(double[] dArr); // this.e = dArr; return this;

    default VecType copy(double[] other) {
        if (this.e() == null) {
            this.setE(Arrays.copyOf(other, 3));
        } else {
            System.arraycopy(other, 0, this.e(), 0, 3);
        }
        return this.self();
    }

    default VecType copy(Vec3Math other) {
        return this.copy(other.e());
    }

    VecType copy(); // deep copy of self

    default double x() {
        return this.e()[0];
    }

    default double y() {
        return this.e()[1];

    }

    default double z() {
        return this.e()[2];

    }

    default double get(int i) {
        return this.e()[i];

    }

    default VecType set(int i, double v) {
        this.e()[i] = v;
        return this.self();
    }

    default VecType plusEqual(Vec3Math other) {
        double[] e = this.e();
        double[] oE = other.e();
        e[0] += oE[0];
        e[1] += oE[1];
        e[2] += oE[2];
        return this.self();
    }

    default VecType minusEqual(Vec3Math other) {
        double[] e = this.e();
        double[] oE = other.e();
        e[0] -= oE[0];
        e[1] -= oE[1];
        e[2] -= oE[2];
        return this.self();
    }

    default VecType timesEqual(Vec3Math other) {
        double[] e = this.e();
        double[] oE = other.e();
        e[0] *= oE[0];
        e[1] *= oE[1];
        e[2] *= oE[2];
        return this.self();
    }

    default VecType timesEqual(double dNum) {
        double[] e = this.e();
        e[0] *= dNum;
        e[1] *= dNum;
        e[2] *= dNum;
        return this.self();
    }

    default VecType divideEqual(double dNum) {
        return this.timesEqual(1 / dNum);
    }

    default double lengthSquared() {
        return this.x() * this.x()
                + this.y() * this.y()
                + this.z() * this.z();
    }

    default double length() {
        return Math.sqrt(this.lengthSquared());
    }

    // Various Utility Functions
    default String asString() {
        return "(" + this.x() + ", " + this.y() + ", " + this.z() + ")";
    }

    default VecType negativeValue() {
        VecType theCopy = this.copy();
        theCopy.timesEqual(-1);
        return theCopy;
    }

    default VecType plus(Vec3Math other) {
        VecType theCopy = this.copy();
        theCopy.plusEqual(other);
        return theCopy;
    }

    default VecType minus(Vec3Math other) {
        VecType theCopy = this.copy();
        theCopy.minusEqual(other);
        return theCopy;

    }

    default VecType times(Vec3Math other) {
        VecType theCopy = this.copy();
        theCopy.timesEqual(other);
        return theCopy;

    }

    default VecType times(double dNum) {
        VecType theCopy = this.copy();
        theCopy.timesEqual(dNum);
        return theCopy;

    }

    static <VecType extends Vec3Math<VecType>>
            VecType times(double dNum, VecType vec) {
        return vec.times(dNum);
    }

    default VecType divide(double dNum) {
        return this.times(1 / dNum);
    }

    default double dot(Vec3Math other) {
        double[] e = this.e();
        double[] oE = other.e();
        return e[0] * oE[0]
                + e[1] * oE[1]
                + e[2] * oE[2];
    }

    default VecType crossEqual(Vec3Math other) {
        double[] e = this.e();
        double[] oE = other.e();
        double x = e[1] * oE[2] - e[2] * oE[1];
        double y = e[2] * oE[0] - e[0] * oE[2];
        double z = e[0] * oE[1] - e[1] * oE[0];
        e[0] = x;
        e[1] = y;
        e[2] = z;
        return this.self();
    }

    default VecType cross(Vec3Math other) {
        VecType theCopy = this.copy();
        theCopy.crossEqual(other);
        return theCopy;

    }

    default VecType unitVector() {
        return this.divide(this.length());
    }

    static <T extends Vec3Math> T randomize(T vec) {
        double[] e = vec.e();
        e[0] = Math.random();
        e[1] = Math.random();
        e[2] = Math.random();

        return vec;
    }

    static <T extends Vec3Math> T randomize(T vec, double min, double max) {
        double[] e = vec.e();
        //e[0] = Math.random() * (max - min) + min;
        e[0] = ThreadLocalRandom.current().nextDouble(min, max);
        e[1] = ThreadLocalRandom.current().nextDouble(min, max);
        e[2] = ThreadLocalRandom.current().nextDouble(min, max);

        return vec;
    }

}