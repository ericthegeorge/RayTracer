/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backend_models;

import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author erick
 */
public class Renderer {

    public final static double ASPECT_RATIO = 16.0 / 9;
    public final static int IMAGE_WIDTH = 384;
    public final static int IMAGE_HEIGHT = (int) (IMAGE_WIDTH / ASPECT_RATIO);
    public static String status = "";
    
    public static boolean hitSphere(Pnt3 center, double radius, Ray r){
        
        Pnt3 oc = r.origin().minus(center);
        double a = r.direction().dot(r.direction());
        double b = (2 * r.direction().dot(oc));
        double c = oc.dot(oc) - radius * radius;
        double discrim = b * b - 4 * a * c;
        return (discrim > 0);
    }
    
    
    public static Colour rayColour(Ray r) {
        
        Pnt3 sphereCenter = Pnt3.valueOf(0, 0, -1);
        double SphereRadius = 0.5;
        
       if (Renderer.hitSphere(sphereCenter, SphereRadius, r)){
           return Colour.valueOf(1, 0, 0);
       }
        
        
        
        Vec3 unitDirection = r.direction().unitVector();
        double t = 0.5 * (unitDirection.y() + 1);

        return Colour.valueOf(1, 1, 1).times(1 - t).plus(Colour.valueOf(0.5, 0.7, 1).times(t));
    }

    public static void render(PicFile targetPic) {
        if (targetPic.getHeight() < Renderer.IMAGE_HEIGHT
                || targetPic.getWidth() < Renderer.IMAGE_WIDTH) {
            throw new RuntimeException("Image width or height not as expected");
        }
        final int imageHeight = Renderer.IMAGE_HEIGHT;
        final int imageWidth = Renderer.IMAGE_WIDTH;

        Pnt3 origin = Pnt3.zero();
        Vec3 horizontal = Vec3.valueOf(4, 0, 0);
        Vec3 vertical = Vec3.valueOf(0, 2.25, 0);
        Pnt3 lowerLeftCorner = origin
                .minus(horizontal.divide(2))
                .minus(vertical.divide(2))
                .minus(Vec3.valueOf(0, 0, 1));

        for (int y = 0; y < imageHeight; ++y) {
            Renderer.status = "Scanlines remaining: " + (imageHeight - y);
            for (int x = 0; x < imageWidth; ++x) {

                double u = (double) x / (imageWidth - 1);
                double v = (double) (imageHeight - 1 - y) / (imageHeight - 1);
                double b = 0.25;

                Ray r = new Ray(origin, Vec3.view(lowerLeftCorner.plus(horizontal.times(u)).plus(vertical.times(v))));

                Colour pixelColour = Renderer.rayColour(r);

                targetPic.setColor(x, y, pixelColour.toColor());
            }

        }
        Renderer.status = "Done";
    }
}
