/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backend_models;

import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author erick
 */
public class Renderer {

    public final static double ASPECT_RATIO = 16.0 / 9;
    public final static int IMAGE_WIDTH = 384;
    public final static int IMAGE_HEIGHT = (int) (IMAGE_WIDTH / ASPECT_RATIO);
    public static String status = "";

//    public static double hitSphere(Pnt3 center, double radius, Ray r) {
//
//        Pnt3 oc = r.origin().minus(center);
//        double a = r.direction().lengthSquared();
//        double half_b = r.direction().dot(oc);
//        double c = oc.lengthSquared() - radius * radius;
//        double discrim = half_b * half_b - a * c;
//        if (discrim > 0) {
//            return (-half_b - Math.sqrt(discrim)) / a;
//        }
//        return -1;
//    }
    public static Colour rayColour(Ray r, HittableList world, int depth) {
        if (depth <= 0) {
            return Colour.zero();
        }

        HitRecord rec = new HitRecord();
        if (world.hit(r, 0.001, Double.POSITIVE_INFINITY, rec)) {

            //Specular Reflection
            
            //Difuse Reflection
            
//            Vec3 nextRayDir = rec.normal.plus(Vec3. randomUnitVector());
//            
//            Ray nextRay = new Ray(rec.p, nextRayDir);
//            Colour nextColour = Renderer.rayColour(nextRay, world, depth - 1);
//            return nextColour.times(0.5);
            
            Colour attenuationOut = Colour.zero();
            Ray nextRay = new Ray();
            boolean scatterValid = rec.mat.scatter(r, rec, attenuationOut, nextRay);
            if (scatterValid) {
                Colour nextColour = Renderer.rayColour(nextRay, world, depth - 1);
                return nextColour.times(attenuationOut);
            } else {
                return Colour.zero();
            }



        }
//            return Colour.valueOf(
//                    (rec.normal.x() + 1) * 0.5,
//                    (rec.normal.y() + 1) * 0.5,
//                    (rec.normal.z() + 1) * 0.5);
//        }

        Vec3 unitDirection = r.direction().unitVector();
        double t = 0.5 * (unitDirection.y() + 1.0);

        return Colour.valueOf(1, 1, 1).times(1 - t).
                plus(Colour.valueOf(0.5, 0.7, 1).times(t));
    }

    public static void render(PicFile targetPic) {
        if (targetPic.getHeight() < Renderer.IMAGE_HEIGHT
                || targetPic.getWidth() < Renderer.IMAGE_WIDTH) {
            throw new RuntimeException("Image width or height not as expected");
        }
        final int imageHeight = Renderer.IMAGE_HEIGHT;
        final int imageWidth = Renderer.IMAGE_WIDTH;
        final int samplesPerPixel = 100;
        final int maxDepth = 50;

        Camera cam = new Camera();
        //world
        HittableList theWorld = new HittableList();
// Lambertian x2
        theWorld.add(new Sphere(Pnt3.valueOf(0, 0, -1), 0.5, new Lambertian(Colour.valueOf(0.1, 0.2, 0.5))));
        theWorld.add(new Sphere(Pnt3.valueOf(0, -100.5, -1), 100, new Lambertian(Colour.valueOf(0.8, 0.8, 0))));

// Metal
        theWorld.add(new Sphere(Pnt3.valueOf(1, 0, -1), 0.5, new Metal(Colour.valueOf(.8, .6, .2), 0.3)));

// Glass x2
        theWorld.add(new Sphere(Pnt3.valueOf(-1, 0, -1), 0.5, new Dielectric(1.5)));
        theWorld.add(new Sphere(Pnt3.valueOf(-1, 0, -1), -0.4, new Dielectric(1.5))); // negative sphere inside one above!
        for (int y = 0; y < imageHeight; ++y) {
            Renderer.status = "Scanlines remaining: " + (imageHeight - y);
            for (int x = 0; x < imageWidth; ++x) {
                Colour pixelColour = Colour.zero();
                for (int s = 0; s < samplesPerPixel; ++s) {
                    double u = (double) (x + Math.random()) / (imageWidth - 1);
                    double v = (double) (imageHeight - 1 - y + Math.random()) 
                            / (imageHeight - 1);

                    Ray r = cam.getRay(u, v);
                    pixelColour.plusEqual(Renderer.rayColour(r, theWorld, maxDepth));
                }
                targetPic.setColor(x, y, pixelColour.toColor(samplesPerPixel));
            }
        }
        Renderer.status = "Done";
    }
}
