/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backend_models;

import java.awt.Color;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author erick
 */
public class Renderer {

    public static String status = "";

    public static void render(PicFile targetPic) {
        int imageHeight = targetPic.getHeight();
        int imageWidth = targetPic.getWidth();
        for (int y = 0; y < imageHeight; ++y) {
            Renderer.status = "Scanlines remaining: " + (imageHeight - y);
            for (int x = 0; x < imageWidth; ++x) {

                double r = (double) x / (imageWidth - 1);
                double g = (double) (imageHeight - 1 - y) / (imageHeight - 1);
                double b = 0.25;

                int ir = (int) (255.9999 * r);
                int ig = (int) (255.9999 * g);
                int ib = (int) (255.9999 * b);

                targetPic.setColor(x, y, new Color(ir, ig, ib));
            }

        }
        Renderer.status = "Done";
    }
}
