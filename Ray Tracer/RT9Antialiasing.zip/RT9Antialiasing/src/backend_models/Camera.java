/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backend_models;

/**
 *
 * @author erick
 */
public class Camera {

    private Pnt3 origin;
    private Vec3 horizontal;
    private Vec3 vertical;
    private Pnt3 lowerLeftCorner;

    public Camera() {
        this.origin = Pnt3.zero();
        this.horizontal = Vec3.valueOf(4, 0, 0);
        this.vertical = Vec3.valueOf(0, 2.25, 0);
        this.lowerLeftCorner = origin
                .minus(horizontal.divide(2))
                .minus(vertical.divide(2))
                .minus(Vec3.valueOf(0, 0, 1));
    }

    public Ray getRay(double u, double v) {
        return new Ray(origin,
                Vec3.view(lowerLeftCorner
                        .plus(horizontal
                                .times(u))
                        .plus(vertical
                                .times(v))
                        .minus(this.origin)
                ));
    }
}
