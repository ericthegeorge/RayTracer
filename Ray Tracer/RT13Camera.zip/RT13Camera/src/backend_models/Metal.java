/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backend_models;

/**
 *
 * @author erick
 */
public class Metal implements Material {

    public Colour albedo;
    public double fuzz;

    public Metal(Colour albedo, double fuzz) {
        this.albedo = albedo;

        if (fuzz < 1) {
            this.fuzz = fuzz;
        } else {
            this.fuzz = 1;
        }
    }

    @Override
    public boolean scatter(Ray rIn, HitRecord rec, Colour attenuationOut, Ray rOut) {
        attenuationOut.copy(this.albedo);
        Vec3 nextRayDir = Vec3.reflect(rIn.direction().unitVector(), rec.normal);
        
        rOut.set(rec.p, nextRayDir.plus
        (Vec3.randomUnitVector().times(this.fuzz))
        );
        return nextRayDir.dot(rec.normal) > 0;
    }

}
