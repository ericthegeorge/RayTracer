/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backend_models;

/**
 *
 * @author erick
 */
public class Camera {

    private Pnt3 origin;
    private Vec3 horizontal;
    private Vec3 vertical;
    private Pnt3 lowerLeftCorner;
    private Vec3 uVec, vVec, wVec;

    public Camera(Pnt3 lookFrom, Pnt3 lookAt, Vec3 vup, double vFovDeg, double aspectRatio) {
        this.origin = lookFrom;
        double theta = Math.toRadians(vFovDeg);
        double halfHeight = Math.tan(theta / 2);
        double halfWidth = aspectRatio * halfHeight;
        
        this.wVec = Vec3.view(lookFrom.minus(lookAt).unitVector());
        this.uVec = vup.cross(this.wVec).unitVector();
        this.vVec = this.wVec.cross(this.uVec);
        
        this.horizontal = this.uVec.times(2 * halfWidth);
        this.vertical = this.vVec.times(2 * halfHeight);
        this.lowerLeftCorner = origin
                .minus(horizontal.divide(2))
                .minus(vertical.divide(2))
                .minus(wVec);
    }

    public Ray getRay(double u, double v) {
        return new Ray(origin,
                Vec3.view(lowerLeftCorner
                        .plus(horizontal
                                .times(u))
                        .plus(vertical
                                .times(v))
                        .minus(this.origin)
                ));
    }
}
