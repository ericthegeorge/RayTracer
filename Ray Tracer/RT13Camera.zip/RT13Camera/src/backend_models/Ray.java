/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package backend_models;

/**
 *
 * @author erick
 */
public class Ray {
    public Pnt3 origin;
    public Vec3 direction;
    
    public Ray() {
        this.origin = Pnt3.zero();
        this.direction = Vec3.zero();
    }
    
    public Ray(Pnt3 origin, Vec3 dir) {
        this.origin = origin;
        this.direction = dir;
    }
    
    public Ray set(Pnt3 origin, Vec3 dir) {
     this.origin = origin;
     this.direction = dir;
     return this;
    }
    public Pnt3 origin() {
        return this.origin;
    }
    public Vec3 direction() {
        return this.direction;
    }
    
    public Pnt3 at(double t) {
        return this.origin.plus(this.direction.times(t)); 
    }
}

