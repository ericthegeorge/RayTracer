package backend_models;

import java.awt.Color;

/**
 * Colour represents RGB with each component ranging from 0 to 1 inclusive.
 *
 * @author cheng
 */
public class Vec3 implements Vec3Math<Vec3> {

    public double[] e;

    private Vec3() {
    }

    // factory and utility functions
    @Override
    public String toString() {
        return this.asString();
    }

    public static Vec3 valueOf(Vec3Math other) {
        // makes a Colour representation of other
        return (new Vec3()).copy(other);

    }

    public static Vec3 valueOf(double x, double y, double z) {
        // makes a Colour that's (x, y, z)
        Vec3 newOne = new Vec3();
        newOne.e = new double[]{x, y, z};
        return newOne;

    }

    public static Vec3 view(Vec3Math other) {
        //makes a Colour that *shares* the underlying (x, y, z) with other
        Vec3 newOne = new Vec3();
        newOne.e = other.e();
        return newOne;
    }

    public static Vec3 zero() {
        //return Colour value of black i.e. (0, 0, 0)
        Vec3 newOne = new Vec3();
        newOne.e = new double[3];
        return newOne;
    }


    // code gen implement abstract methods
    @Override
    public Vec3 self() {
        return this;//To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public double[] e() {
        return this.e;
    }

    @Override
    public Vec3 setE(double[] dArr) {
        this.e = dArr;
        return this;
    }

    @Override
    public Vec3 copy() {
        Vec3 copy = new Vec3();
        copy.copy(this);
        return copy;
    }
}
